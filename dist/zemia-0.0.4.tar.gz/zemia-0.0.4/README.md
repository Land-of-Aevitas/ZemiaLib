# ZemiaLib by OK_Diamond

This library was created to store various bits of code that I use across multiple projects, primarily relating to Zemia.
