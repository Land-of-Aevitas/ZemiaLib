from src.zemia import common

def test_empty():
    assert common.empty(["", 0])
